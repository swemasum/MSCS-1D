<?php

//$conn = $conn = mysqli_connect("localhost","incotpwz_video","softDKA2018","incotpwz_video");
$conn = $conn = mysqli_connect("localhost","root","","simulator");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
}else{

}
?>
