<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="">
        <meta name="author" content="">
        <title>simulator</title>
        <!-- Bootstrap core CSS -->
        <link href="bootstrap/css/bootstrap.css" rel="stylesheet">
        <!-- Custom styles for this template -->
        <link href="style.css" rel="stylesheet">
		<script src="Chart.js-2.7.2/dist/Chart.min.js"></script>
			<style type="text/css">
ul#mylist  {

  top: 5px;
  bottom: 5px;
  left: 15px;
  right: 5px;
  overflow: scroll;
  margin: 0;
  padding: 0;

  border: 2px solid #ccc;

  font-size: 14px;
  font-family: Arial, sans-serif;

  // Again, this is where the magic happens
  -webkit-overflow-scrolling: touch;
}


td { padding-left:5px; }
</style>
    </head>
    <body>
        <div class="container">
</div>
        <div class="row">
            <div class="col-md-12" style="padding:5px">
                <center>
                    <h3 style="color:green;font-weight:bold">Cell 1</h3>
                </center>
            </div>
        </div>
        <!-- Bootstrap core JavaScript
    ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->
        <div class="row col-lg-12" style="padding:5px">
            <div class="row col-lg-2 col-md-2 col-sm-2 "> </div>
            <div class="row col-lg-8 row-md-8 col-sm-8 col-xs-8" style="padding:5px">
                <div class="col-md-4 border">
                    <h3>Column title</h3>
                    <p></p>
                    <div class="form-group">
                        <label for="formInput106">M<sub style="font-size: 15px;">c</sub></label>
                           <input type="number" class="form-control"/>
                    </div>
                    <div class="form-group">
                        <label for="formInput116">Field label</label>
                        <select id="formInput116" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput128">Field label</label>
                        <select id="formInput128" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput138">Field label</label>
                        <select id="formInput138" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput146">Field label</label>
                        <select id="formInput146" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput156">Field label</label>
                        <select id="formInput156" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput172">Field label</label>
                        <select id="formInput172" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4 border">
                    <h3>Column title</h3>
                    <p></p>
                    <div class="form-group">
                        <label for="formInput106">Field label</label>
                        <select id="formInput106" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput116">Field label</label>
                        <select id="formInput116" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput128">Field label</label>
                        <select id="formInput128" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput138">Field label</label>
                        <select id="formInput138" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput146">Field label</label>
                        <select id="formInput146" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput156">Field label</label>
                        <select id="formInput156" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput172">Field label</label>
                        <select id="formInput172" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                </div>
                <div class="col-md-4 border">
                    <h3>Column title</h3>
                    <p></p>
                    <div class="form-group">
                        <label for="formInput106">Field label</label>
                        <select id="formInput106" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput116">Field label</label>
                        <select id="formInput116" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput128">Field label</label>
                        <select id="formInput128" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput138">Field label</label>
                        <select id="formInput138" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput146">Field label</label>
                        <select id="formInput146" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput156">Field label</label>
                        <select id="formInput156" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="formInput172">Field label</label>
                        <select id="formInput172" class="form-control">
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="row col-lg-2 "> </div>
            <div class="row col-lg-2 "> </div>
            <div class="row col-lg-8 ">
                <div class="col-md-4">
                    <center>
                        <button type="button" class="btn btn-info">Save</button>
                    </center>
                </div>
                <div class="col-md-4">
                    <center>
                        <button type="button" class="btn btn-success" data-target="#exampleModal1" data-toggle="modal">Line Graph</button>
                    </center>
                </div>
                <div class="col-md-4">
                    <center>
                        <button type="button" class="btn btn-danger" data-target="#exampleModal2" data-toggle="modal">Bar Graph</button>
                    </center>
                </div>
            </div>
        </div>

		<!--line chart-->
		    <table>

      <tr>

        <td>
          <div tabindex="-1" class="modal fade" id="exampleModal1" role="dialog" aria-hidden="true" aria-labelledby="exampleModalLabel" style="display: none;">
            <div class="modal-dialog modal-lg" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h2 class="modal-title" id="exampleModalLabel">
                    LINE CHART
                  </h2><button class="close" aria-label="Close" type="button" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body">
                  <div class="container-fluid">


                    <div class="row">
                      <div class="col-sm-12">

            <canvas id="line-chart"></canvas>


                      </div>


                    </div>

                  </div>
                </div>
                <div class="modal-footer">
                  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                </div>
              </div>
            </div>
          </div>
        </td>
      </tr>
    </table>
	<script type="text/javascript">
$('#myModal').on('shown.bs.modal1', function () {
  $('#myInput').trigger('focus')
})

</script>
<script>
var abc=[{x:1.44,y:744},{x:1.1,y:500},{x:2.4,y:200}];
new Chart(document.getElementById("line-chart"), {
  type: 'line',
  data: {
    labels: [0,0.2,0.4,0.6,0.8,1,1.2,1.4,1.6,1.8,2],
    datasets: [{
        data: abc,
        label: "Africa",
        borderColor: "#3e95cd",
        fill: false
      }
    ]
  },
  options: {
    title: {
      display: true,
      text: 'World population per region (in millions)'
    }
  }
});
</script>
	<!--line chart end -->
	<!--bar chart  -->
			    <table>

      <tr>

        <td>
          <div tabindex="-1" class="modal fade" id="exampleModal2" role="dialog" aria-hidden="true" aria-labelledby="exampleModalLabel" style="display: none;">
            <div class="modal-dialog modal-lg" role="document">
              <div class="modal-content">
                <div class="modal-header">
                  <h2 class="modal-title" id="exampleModalLabel">
                    BAR CHART
                  </h2><button class="close" aria-label="Close" type="button" data-dismiss="modal"><span aria-hidden="true">×</span></button>
                </div>
                <div class="modal-body">
                  <div class="container-fluid">


                    <div class="row">
                      <div class="col-sm-12">

            <canvas id="myChart"></canvas>


                      </div>


                    </div>

                  </div>
                </div>
                <div class="modal-footer">
                  <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                </div>
              </div>
            </div>
          </div>
        </td>
      </tr>
    </table>
	<script>
var ctx = document.getElementById("myChart").getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ["Red", "Blue", "Yellow", "Green", "Purple", "Orange"],
        datasets: [{
            label: '# of Votes',
            data: [12, 19, 3, 5, 2, 3],
            backgroundColor: [
                'rgba(255, 99, 132, 0.2)',
                'rgba(54, 162, 235, 0.2)',
                'rgba(255, 206, 86, 0.2)',
                'rgba(75, 192, 192, 0.2)',
                'rgba(153, 102, 255, 0.2)',
                'rgba(255, 159, 64, 0.2)'
            ],
            borderColor: [
                'rgba(255,99,132,1)',
                  'rgba(54, 162, 235, 1)',
                'rgba(255, 206, 86, 1)',
                'rgba(75, 192, 192, 1)',
                'rgba(153, 102, 255, 1)',
                'rgba(255, 159, 64, 1)'
            ],
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero:true
                }
            }]
        }
    }
});
</script>
	<!--bar chart end -->
        <script src="assets/js/jquery.min.js"></script>
        <script src="assets/js/popper.js"></script>
        <script src="bootstrap/js/bootstrap.min.js"></script>
        <!-- IE10 viewport hack for Surface/desktop Windows 8 bug -->
        <script src="assets/js/ie10-viewport-bug-workaround.js"></script>
    </body>
</html>
