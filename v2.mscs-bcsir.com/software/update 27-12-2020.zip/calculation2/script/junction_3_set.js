
					
							function myFunction() {
								var x = document.getElementById("mySelect").value;
								console.log(x)
								if(x=="GaInP2"){
								
								var mc=1;
								var mv=3;
								var mue=0.4;
								var muh=0.02;
								var me=0.155*9.1e-31;
								var mh= 0.460*9.1e-31;
								var srh= 1e-5;
								var b=7.5e-16;
								var na=1e23;
								var nd=2e24;
								var xn=208e-9;
								var xp=100e-9;
								var lamda=0.65428e-6;
								var eg=1.9;
								
								document.getElementById("mc").value = mc;
								document.getElementById("mv").value = mv;
								document.getElementById("mue").value = mue;
								document.getElementById("muh").value = muh;
								document.getElementById("me").value = me;
								document.getElementById("mh").value = mh;
								document.getElementById("srh").value = srh;
								document.getElementById("b").value = b;
								document.getElementById("na").value = na;
								document.getElementById("nd").value = nd;
								document.getElementById("xn").value = xn;
								document.getElementById("xp").value = xp;
								document.getElementById("lamda").value = lamda;
								document.getElementById("eg").value = eg;
								}else if(x=="GaAs"){
										
								var mc=1;
								var mv=1;
								var mue=0.2322;
								var muh=0.02;
								var me=0.067*9.1e-31;
								var mh= 0.473*9.1e-31;
								var srh= 1e-5;
								var b=7.5e-16;
								var na=9e23;
								var nd=7.8e23;
								var xn=300e-9;
								var xp=100e-9;
								var lamda=0.875e-6;
								var eg=1.42;
								
								document.getElementById("mc").value = mc;
								document.getElementById("mv").value = mv;
								document.getElementById("mue").value = mue;
								document.getElementById("muh").value = muh;
								document.getElementById("me").value = me;
								document.getElementById("mh").value = mh;
								document.getElementById("srh").value = srh;
								document.getElementById("b").value = b;
								document.getElementById("na").value = na;
								document.getElementById("nd").value = nd;
								document.getElementById("xn").value = xn;
								document.getElementById("xp").value = xp;
								document.getElementById("lamda").value = lamda;
								document.getElementById("eg").value = eg;
								}else if(x=="ge"){
								var mc=1;
								var mv=1;
								var mue=0.39;
								var muh=0.19;
								var me=1.64*9.1e-31;
								var mh= 0.28*9.1e-31;
								var srh= 1e-5;
								var b=7.5e-16;
								var na=1e23;
								var nd=2e24;
								var xn=400e-9;
								var xp=100e-9;
								var lamda=1.775e-6;
								var eg=0.67;
								
								document.getElementById("mc").value = mc;
								document.getElementById("mv").value = mv;
								document.getElementById("mue").value = mue;
								document.getElementById("muh").value = muh;
								document.getElementById("me").value = me;
								document.getElementById("mh").value = mh;
								document.getElementById("srh").value = srh;
								document.getElementById("b").value = b;
								document.getElementById("na").value = na;
								document.getElementById("nd").value = nd;
								document.getElementById("xn").value = xn;
								document.getElementById("xp").value = xp;
								document.getElementById("lamda").value = lamda;
								document.getElementById("eg").value = eg;
								}
								
							}
							
							function myFunction2() {
								var x = document.getElementById("mySelect2").value;
								console.log(x)
								if(x=="GaInP2"){
								
								var mc=1;
								var mv=3;
								var mue=0.4;
								var muh=0.02;
								var me=0.155*9.1e-31;
								var mh= 0.460*9.1e-31;
								var srh= 1e-5;
								var b=7.5e-16;
								var na=1e23;
								var nd=2e24;
								var xn=208e-9;
								var xp=100e-9;
								var lamda=0.65428e-6;
								var eg=1.9;
								
								document.getElementById("mc2").value = mc;
								document.getElementById("mv2").value = mv;
								document.getElementById("mue2").value = mue;
								document.getElementById("muh2").value = muh;
								document.getElementById("me2").value = me;
								document.getElementById("mh2").value = mh;
								document.getElementById("srh2").value = srh;
								document.getElementById("b2").value = b;
								document.getElementById("na2").value = na;
								document.getElementById("nd2").value = nd;
								document.getElementById("xn2").value = xn;
								document.getElementById("xp2").value = xp;
								document.getElementById("lamda2").value = lamda;
								document.getElementById("eg2").value = eg;
								}else if(x=="GaAs"){
										
								var mc=1;
								var mv=1;
								var mue=0.2322;
								var muh=0.02;
								var me=0.067*9.1e-31;
								var mh= 0.473*9.1e-31;
								var srh= 1e-5;
								var b=7.5e-16;
								var na=9e23;
								var nd=7.8e23;
								var xn=300e-9;
								var xp=100e-9;
								var lamda=0.875e-6;
								var eg=1.42;
								
								document.getElementById("mc2").value = mc;
								document.getElementById("mv2").value = mv;
								document.getElementById("mue2").value = mue;
								document.getElementById("muh2").value = muh;
								document.getElementById("me2").value = me;
								document.getElementById("mh2").value = mh;
								document.getElementById("srh2").value = srh;
								document.getElementById("b2").value = b;
								document.getElementById("na2").value = na;
								document.getElementById("nd2").value = nd;
								document.getElementById("xn2").value = xn;
								document.getElementById("xp2").value = xp;
								document.getElementById("lamda2").value = lamda;
								document.getElementById("eg2").value = eg;
								}else if(x=="ge"){
								var mc=1;
								var mv=1;
								var mue=0.39;
								var muh=0.19;
								var me=1.64*9.1e-31;
								var mh= 0.28*9.1e-31;
								var srh= 1e-5;
								var b=7.5e-16;
								var na=1e23;
								var nd=2e24;
								var xn=400e-9;
								var xp=100e-9;
								var lamda=1.775e-6;
								var eg=0.67;
								
								document.getElementById("mc2").value = mc;
								document.getElementById("mv2").value = mv;
								document.getElementById("mue2").value = mue;
								document.getElementById("muh2").value = muh;
								document.getElementById("me2").value = me;
								document.getElementById("mh2").value = mh;
								document.getElementById("srh2").value = srh;
								document.getElementById("b2").value = b;
								document.getElementById("na2").value = na;
								document.getElementById("nd2").value = nd;
								document.getElementById("xn2").value = xn;
								document.getElementById("xp2").value = xp;
								document.getElementById("lamda2").value = lamda;
								document.getElementById("eg2").value = eg;
								}
								
							}
							
							function myFunction3() {
								var x = document.getElementById("mySelect3").value;
								console.log(x)
								if(x=="GaInP2"){
								
								var mc=1;
								var mv=3;
								var mue=0.4;
								var muh=0.02;
								var me=0.155*9.1e-31;
								var mh= 0.460*9.1e-31;
								var srh= 1e-5;
								var b=7.5e-16;
								var na=1e23;
								var nd=2e24;
								var xn=208e-9;
								var xp=100e-9;
								var lamda=0.65428e-6;
								var eg=1.9;
								
								document.getElementById("mc3").value = mc;
								document.getElementById("mv3").value = mv;
								document.getElementById("mue3").value = mue;
								document.getElementById("muh3").value = muh;
								document.getElementById("me3").value = me;
								document.getElementById("mh3").value = mh;
								document.getElementById("srh3").value = srh;
								document.getElementById("b3").value = b;
								document.getElementById("na3").value = na;
								document.getElementById("nd3").value = nd;
								document.getElementById("xn3").value = xn;
								document.getElementById("xp3").value = xp;
								document.getElementById("lamda3").value = lamda;
								document.getElementById("eg3").value = eg;
								}else if(x=="GaAs"){
										
								var mc=1;
								var mv=1;
								var mue=0.2322;
								var muh=0.02;
								var me=0.067*9.1e-31;
								var mh= 0.473*9.1e-31;
								var srh= 1e-5;
								var b=7.5e-16;
								var na=9e23;
								var nd=7.8e23;
								var xn=300e-9;
								var xp=100e-9;
								var lamda=0.875e-6;
								var eg=1.42;
								
								document.getElementById("mc3").value = mc;
								document.getElementById("mv3").value = mv;
								document.getElementById("mue3").value = mue;
								document.getElementById("muh3").value = muh;
								document.getElementById("me3").value = me;
								document.getElementById("mh3").value = mh;
								document.getElementById("srh3").value = srh;
								document.getElementById("b3").value = b;
								document.getElementById("na3").value = na;
								document.getElementById("nd3").value = nd;
								document.getElementById("xn3").value = xn;
								document.getElementById("xp3").value = xp;
								document.getElementById("lamda3").value = lamda;
								document.getElementById("eg3").value = eg;
								}else if(x=="ge"){
								var mc=1;
								var mv=1;
								var mue=0.39;
								var muh=0.19;
								var me=1.64*9.1e-31;
								var mh= 0.28*9.1e-31;
								var srh= 1e-5;
								var b=7.5e-16;
								var na=1e23;
								var nd=2e24;
								var xn=400e-9;
								var xp=100e-9;
								var lamda=1.775e-6;
								var eg=0.67;
								
								document.getElementById("mc3").value = mc;
								document.getElementById("mv3").value = mv;
								document.getElementById("mue3").value = mue;
								document.getElementById("muh3").value = muh;
								document.getElementById("me3").value = me;
								document.getElementById("mh3").value = mh;
								document.getElementById("srh3").value = srh;
								document.getElementById("b3").value = b;
								document.getElementById("na3").value = na;
								document.getElementById("nd3").value = nd;
								document.getElementById("xn3").value = xn;
								document.getElementById("xp3").value = xp;
								document.getElementById("lamda3").value = lamda;
								document.getElementById("eg3").value = eg;
								}
								
							}